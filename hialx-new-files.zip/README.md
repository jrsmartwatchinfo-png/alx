# AI চ্যাটবট (Google Gemini)

Python (FastAPI) + HTML চ্যাট UI। চ্যাট পেজ `app.py` এর ভেতরেই আছে।

## নিজের পিসিতে চালানো
```
pip install -r requirements.txt
```
`.env.example` এর নাম বদলে `.env` করে `GOOGLE_API_KEY` বসান, তারপর:
```
uvicorn app:app --reload
```
ব্রাউজারে http://127.0.0.1:8000

## Render-এ ডিপ্লয়
`render.yaml` আছে। Render-এ `GOOGLE_API_KEY` সেট করুন।
